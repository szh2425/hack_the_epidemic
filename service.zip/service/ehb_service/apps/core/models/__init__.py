'''
Created on Jun 13, 2011

@author: masinoa
'''

from core.models.identities import *
from core.models.clients import *
