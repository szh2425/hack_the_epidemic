class CheckSumFailure(Exception):
    pass
