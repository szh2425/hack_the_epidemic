1.0.5
  * added nautlis error messages to biorepository UI. fixing issue #29

1.0.4
  * fixing issue8 - driver execption: adding additional nautilius issue mappings
  * added additional nautlis mappings -  'SER': 'Serum'
  * added nautlis error messages to biorepository UI

1.0.3
-----
* Add additional Nautilus mappings
  * Saliva
  * Slide
  * Cell Line
  * Supernant
  * Cell Pellet
  * QC Gel
  * QC Xpose
  * QC Agilent
* Add logging facilities to identify unmapped sample types as they come through.

1.0.2
-----
* Adds exception handling for empty REDCap responses

1.0.1
-----
* Ensure that form url's end in a `/` to prevent Django from having to force a redirect.

1.0.0
-----
* Initital Release
